A Painless QR Scanner.

Only for web links.

Scan, view, open. Nothing else.

![sample](https://github.com/Rk87580/Prodigy_QR/assets/129936493/a57eb435-f7fb-4f94-98ae-099adeffddf7)
![dialog](https://github.com/Rk87580/Prodigy_QR/assets/129936493/b9e4b64c-c853-4359-b985-de23a90c6638)
![logo](https://github.com/Rk87580/Prodigy_QR/assets/129936493/4b3dbd51-bc31-45f9-9015-218750f57a36)
